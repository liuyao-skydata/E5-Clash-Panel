/* E5: the SMS detail view gets a reply key -- it opens the message plugin with
   the sender already filled in, and the editor focused on the body. */
(function () {
    const btn = document.getElementById('sv-reply');
    if (!btn) return;
    const zh = () => document.documentElement.lang !== 'en';
    btn.textContent = zh() ? '\u56de\u590d' : 'Reply';
    const frame = document.getElementById('app-frame');
    if (frame) {
        frame.addEventListener('load', function () {
            const to = window.__e5ComposeTo;
            if (!to || frame.hidden) return;
            window.__e5ComposeTo = null;
            try { frame.contentWindow.postMessage({ e5: 'compose', to: to }, '*'); } catch (e) {}
        });
    }
    btn.onclick = function () {
        const m = smsList.find(function (x) { return x.id == smsOpen; });
        if (!m || !m.number) { toast(t('unknown_sender')); return; }
        window.__e5ComposeTo = String(m.number);
        closeSms();
        openAppById('smssend');
    };
})();

