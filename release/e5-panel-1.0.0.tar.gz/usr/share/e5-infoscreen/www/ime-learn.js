/* E5 IME helper: Hunan-frequent words/chars first + personal usage learning.
 * Loaded by the keypad plugins as /ime-learn.js. Nothing here touches the
 * dictionary file; it only re-orders (and tops up) the visible candidate list. */
window.E5IME = (function () {
    var KEY = 'e5ime.learn.v1';
    var store = {};
    try { store = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { store = {}; }

    /* Hunan place names / dialect words that the dictionary does not carry.
       Format: first-syllable|pinyin.word,pinyin.word */
    var ROWS = [
        "shao|shao.yang=邵阳",
        "shao|shao.shan=韶山",
        "shao|shao.shan.chong=韶山冲",
        "yue|yue.yang=岳阳",
        "yue|yue.lu=岳麓",
        "yue|yue.lu.shan=岳麓山",
        "yue|yue.yang.lou=岳阳楼",
        "yi|yi.yang=益阳",
        "yi|yi.zhang=宜章",
        "lou|lou.di=娄底",
        "chen|chen.zhou=郴州",
        "chen|chen.xi=辰溪",
        "yong|yong.zhou=永州",
        "huai|huai.hua=怀化",
        "ning|ning.xiang=宁乡",
        "wang|wang.cheng=望城",
        "cha|cha.ling=茶陵",
        "cha|cha.you=茶油",
        "yan|yan.ling=炎陵",
        "lei|lei.yang=耒阳",
        "chang|chang.ning=常宁",
        "qi|qi.dong=祁东",
        "qi|qi.yang=祁阳",
        "shuang|shuang.pai=双牌",
        "shuang|shuang.feng=双峰",
        "dao|dao.xian=道县",
        "jiang|jiang.yong=江永",
        "lan|lan.shan=蓝山",
        "xin|xin.tian=新田",
        "xin|xin.huang=新晃",
        "xin|xin.hua=新化",
        "xin|xin.ning=新宁",
        "gui|gui.yang=桂阳",
        "gui|gui.dong=桂东",
        "ru|ru.cheng=汝城",
        "zi|zi.xing=资兴",
        "zi|zi.jiang=资江",
        "jia|jia.he=嘉禾",
        "lin|lin.wu=临武",
        "lin|lin.xiang=临湘",
        "lin|lin.li=临澧",
        "an|an.ren=安仁",
        "an|an.hua=安化",
        "tao|tao.jiang=桃江",
        "tao|tao.hua.yuan=桃花源",
        "xiang|xiang.yin=湘阴",
        "xiang|xiang.tan.bin.lang=湘潭槟榔",
        "xiang|xiang.xiu=湘绣",
        "xiang|xiang.ju=湘剧",
        "xiang|xiang.lian=湘莲",
        "xiang|xiang.xi.la.rou=湘西腊肉",
        "xiang|xiang.ren=湘人",
        "mi|mi.luo=汨罗",
        "ci|ci.li=慈利",
        "sang|sang.zhi=桑植",
        "han|han.shou=汉寿",
        "li|li.xian=澧县",
        "li|li.shui=澧水",
        "li|li.shou=里手",
        "yuan|yuan.ling=沅陵",
        "yuan|yuan.shui=沅水",
        "xu|xu.pu=溆浦",
        "jing|jing.zhou=靖州",
        "jing|jing.gang=靖港",
        "zhi|zhi.jiang=芷江",
        "ma|ma.yang=麻阳",
        "ma|ma.la=麻辣",
        "leng|leng.shui.jiang=冷水江",
        "lian|lian.yuan=涟源",
        "lian|lian.ou=莲藕",
        "long|long.hui=隆回",
        "wu|wu.gang=武冈",
        "wu|wu.ling.yuan=武陵源",
        "sui|sui.ning=绥宁",
        "cheng|cheng.bu=城步",
        "yu|yu.hua=雨花",
        "kai|kai.fu=开福",
        "xing|xing.cheng=星城",
        "ju|ju.zi.zhou=橘子洲",
        "xiao|xiao.shui=潇水",
        "hua|hua.ming.lou=花明楼",
        "hua|hua.gu.xi=花鼓戏",
        "tong|tong.guan=铜官",
        "ya|ya.zi=伢子",
        "mei|mei.tuo=妹陀",
        "tang|tang.ke=堂客",
        "tang|tang.you.ba.ba=糖油粑粑",
        "ai|ai.jie=娭毑",
        "die|die.die=嗲嗲",
        "xi|xi.ya.zi=细伢子",
        "ba|ba.man=霸蛮",
        "ga|ga.fan=呷饭",
        "ga|ga.fen=呷粉",
        "ga|ga.cha=呷茶",
        "mao|mao.de=冇得",
        "mao|mao.shi.hong.shao.rou=毛氏红烧肉",
        "ge|ge.za=咯杂",
        "he|he.jie=何解",
        "na|na.men=哪门",
        "xia|xia.bu.de.di=下不得地",
        "xia|xia.bu=夏布",
        "gao|gao.me.zi=搞么子",
        "mo|mo.zi=莫子",
        "hao|hao.man=好蛮",
        "duo|duo.jiao=剁椒",
        "duo|duo.la.jiao=剁辣椒",
        "duo|duo.jiao.yu.tou=剁椒鱼头",
        "kou|kou.wei.xia=口味虾",
        "la|la.yu=腊鱼",
        "la|la.mei.zi=辣妹子",
        "pi|pi.ying=皮影",
        "miao|miao.zhai=苗寨",
        "dong|dong.zhai=侗寨",
        "wei|wei.la=微辣",
        "zhong|zhong.la=中辣",
        "te|te.la=特辣",
    ];
    var EXTRA = {};
    ROWS.forEach(function (row) {
        var i = row.indexOf('|');
        if (i < 0) return;
        var key = row.slice(0, i);
        var cell = row.slice(i + 1);
        var j = cell.indexOf('=');
        if (j < 0) return;
        (EXTRA[key] = EXTRA[key] || []).push({ text: cell.slice(j + 1), py: cell.slice(0, j).replace(/\./g, ' ') });
    });

    var HNC = ' 崽 伢 湘 呷 咯 冇 娭 毑 醴 攸 耒 郴 邵 娄 沅 澧 潇 麓 橘 汨 溆 芷 晃 绥 韶 莲 剁 椒 榔 槟 绣 侗 瑶 苗 ';
    function isHN(it) { if (!it) return false; if (it.hn) return true; var t = it.text || ''; return t.length === 1 && HNC.indexOf(' ' + t + ' ') >= 0; }

    function save() { try { localStorage.setItem(KEY, JSON.stringify(store)); } catch (e) {} }
    function learn(text) {
        if (!text) return;
        store[text] = (store[text] || 0) + 1;
        if (store[text] > 999) store[text] = 999;
        save();
    }
    var HN_POS = 3;   /* boosted items land on this slot (0-based), not slot 1 */
    var HN_CAP = 3;   /* how many boosted items per syllable */
    function reorder(list, py) {
        var arr = (list || []).slice();
        var have = {};
        arr.forEach(function (it) { if (it && it.text) have[it.text] = 1; });
        var extra = (py && EXTRA[py]) ? EXTRA[py] : [];
        extra.forEach(function (x) {
            if (!have[x.text]) { arr.push({ text: x.text, py: x.py, order: 1e9, hn: 1 }); have[x.text] = 1; }
        });

        /* 1. personal usage: most used first, stable inside the same count */
        var learned = [], rest = [];
        arr.forEach(function (it, i) {
            var n = store[it.text] || 0;
            if (n > 0) learned.push({ it: it, n: n, i: i });
            else rest.push(it);
        });
        learned.sort(function (a, b) { return b.n - a.n || a.i - b.i; });
        var out = learned.map(function (x) { return x.it; }).concat(rest);

        /* 2. Hunan words/chars lifted to slot HN_POS (never hijack slot 1-3) */
        var hnAt = [];
        out.forEach(function (it, i) { if (isHN(it) && i >= HN_POS) hnAt.push(i); });
        if (hnAt.length) {
            var pick = hnAt.slice(0, HN_CAP).map(function (i) { return out[i]; });
            var drop = {};
            hnAt.slice(0, HN_CAP).forEach(function (i) { drop[i] = 1; });
            var base = out.filter(function (_, i) { return !drop[i]; });
            var pos = Math.min(HN_POS, base.length);
            pick.forEach(function (it, k) { base.splice(pos + k, 0, it); });
            out = base;
        }
        return out;
    }
    function reset() { store = {}; save(); }
    return { learn: learn, reorder: reorder, reset: reset, store: function () { return store; } };
})();

